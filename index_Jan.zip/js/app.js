jQuery.noConflict();


(function($) {

    (function() {

    window.velocityRun = window.velocityRun || {};

    velocityRun = function(data){
      $.each( data, function( parentKey, parent ) {
        Pname = parent.name || '';
        Pscene = parent.scene || '';
        Tname = (Pscene !== '' ? Pscene +" " + Pname : Pname);
        Selected = $(Tname);

        Psegment = parent.segment || {};

        $.each( Psegment, function(segmentKey, segment){

          isPropertyExist = segment.properties || false;
          isOptionExist = segment.options || false;

          Psegment[segmentKey]['elements'] = Selected;

          $velocityAnimate = $(Tname);
          if(isPropertyExist && isOptionExist && Psegment.length == 1){
            // $velocityAnimate = $velocityAnimate.velocity(segment.properties, segment.options);
          }

        });

        if(Psegment.length > 1){
          console.log(Psegment);

          setInterval(function() {
            $.Velocity.RunSequence(Psegment);
          }, 1000);
        }

      });
    }

    })(window, document, jQuery);

})(jQuery);

(function($) {

    (function() {

        $('nav a').click(function(e) {
          selectQ = $(this).attr("href");
          selectID = "#" + selectQ;
          if ($(selectID).length && selectID != "#home") {
            $('.modalpage').removeClass("modalshow");
            $('nav a').removeClass("active");
            $(this).addClass("active");
            $('.modalpage' + selectID).scrollTop(0);
            $('.modalpage' + selectID).addClass("modalshow");
            $('body').addClass("freeze");
            $('nav').addClass("freeze_nav");
            $('nav').addClass("navbar-page");
          } else {
            $('nav a').removeClass("active");
            $('.modalpage').removeClass("modalshow");
            $('body').removeClass("freeze");
            $('nav').removeClass("freeze_nav");
          }
          e.preventDefault();
        });

        $('a[data-trigger=modal]').click(function(e) {
          selectQ = $(this).attr("href");
          selectID = "#" + selectQ;
          $('.modalcover').fadeIn( "slow" );
          $('.modalpopup' + selectID).find('.content').prepend('<div class=\'close\'>X</div>');
          $('.modalpopup' + selectID).fadeIn( "slow" );
          
          $('body').addClass("freeze");
          $('nav').addClass("freeze_nav");
          e.preventDefault();
        });

        $('a[data-trigger=modal]').click(function(e) {
          selectQ = $(this).attr("href");
          selectID = "#" + selectQ;
          $('.modalcover').fadeIn( "slow" );
          $('.modalpopup' + selectID).fadeIn( "slow" );

          $('body').addClass("freeze");
          $('nav').addClass("freeze_nav");
          e.preventDefault();
        });

        $(function(){
          $('.gallery.gallery-works').mixItUp();  
        });

        //breakdown the labels into single character spans
        $(".flp label").each(function(){
        var sop = '<span class="ch">'; //span opening
        var scl = '</span>'; //span closing
        //split the label into single letters and inject span tags around them
        $(this).html(sop + $(this).html().split("").join(scl+sop) + scl);
        //to prevent space-only spans from collapsing
        $(".ch:contains(' ')").html("&nbsp;");
        })

        var d;
        //animation time
        var flpSelector = ".flp input, .flp textarea";
        $(flpSelector).focus(function(){
        //calculate movement for .ch = half of input height
        // var tm = $(this).outerHeight()/2 * -1 + "px";
        var tm = $(".flp input").outerHeight()/2 * -1 + "px";
        //label = next sibling of input
        //to prevent multiple animation trigger by mistake we will use .stop() before animating any character and clear any animation queued by .delay()
        $(this).next().addClass("focussed").children().stop(true).each(function(i){
          d = i*50;//delay
          $(this).delay(d).animate({top: tm}, 200, 'easeOutBack');
        })
        })
        $(flpSelector).blur(function(){
        //animate the label down if content of the input is empty
        if($(this).val() == "")
        {
          $(this).next().removeClass("focussed").children().stop(true).each(function(i){
            d = i*50;
            $(this).delay(d).animate({top: 0}, 500, 'easeInOutBack');
          })
        }
        })
        $(flpSelector).each(function(){
        $(this).val('');
        })


        var dashlightbulbto = 0;
        var dashlightbulbdelay = 0;

        $(".dashlightbulb").find('path').each(function(){
          dashFrom = "data-_dashlightbulb";
          dashTo = "data-end";
          $(this).attr(dashFrom, "@class:dashlightbulbactivate");
          $(this).attr(dashTo, "@class:dashlightbulbactivate");
          $(this).attr("data-edge-strategy", "reset");

          k = "stroke-dashoffset .3s ease-in-out "+dashlightbulbdelay+'s';
          this.style.WebkitTransition = k;
          this.style.MozTransition = k;
          dashlightbulbdelay += .05;
        });



        var animateData = [
          {
            scene: ".core",
            name: ".p1-brain",
            segment: [
              {
                properties: { scale: 0.9, translateY: "10px" },
                options: { easing: [0, 40, 100], duration: 1000, loop: true }
              }
            ]
          },
          {
            scene: ".core",
            name: ".p2-bulb-1",
            segment: [
              {
                properties: { rotateZ: [ "3", "swing", "-3" ] },
                options: { easing: "swing", duration: 2200, loop: true }
              }
            ]
          },
          {
            scene: ".core",
            name: ".p2-bulb-2",
            segment: [
              {
                properties: { rotateZ: [ "3", "swing", "-3" ] },
                options: { easing: "swing", duration: 2000, loop: true }
              }
            ]
          },
          {
            scene: ".core",
            name: ".p2-bulb-3",
            segment: [
              {
                properties: { rotateZ: [ "3", "swing", "-3" ] },
                options: { easing: "swing", duration: 2500, loop: true }
              }
            ]
          },
          // {
          //   scene: ".core",
          //   name: ".p1-machine",
          //   segment: [
          //     {
          //       properties: { translateY: 300 },
          //       options: { easing: "swing", duration: 500 }
          //     },
          //     {
          //       properties: { translateX: 600 },
          //       options: { easing: "swing", duration: 500 }
          //     }
          //   ]
          // }
        ]
        
        window.onload = function() {
            velocityRun(animateData);
            skrollr.init({
              forceHeight: true,
              smoothScrolling: true,
              constants: {
                  dashlightbulb: 8265,
                  p1circles: 800
              }
            });
        }

    })(window, document, jQuery);

})(jQuery);